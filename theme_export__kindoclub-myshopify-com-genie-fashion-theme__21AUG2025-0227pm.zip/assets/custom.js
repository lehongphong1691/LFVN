

function toggleAnswer(button) {
      const faqContainer = button.closest('.faq-container');
      const faqItems = faqContainer.querySelectorAll('.faq-item');

      faqItems.forEach(item => {
          const answer = item.querySelector('.faq-answer');
          if (item !== button.closest('.faq-item')) {
              item.classList.remove('active');
              answer.style.display = 'none';
          }
      });

      const faqItem = button.closest('.faq-item');
      const answer = faqItem.querySelector('.faq-answer');

      if (faqItem.classList.contains('active')) {
          faqItem.classList.remove('active');
          answer.style.display = 'none';
      } else {
          faqItem.classList.add('active');
          answer.style.display = 'block';
      }
  }




 document.addEventListener("DOMContentLoaded", function () {
  const headers = document.querySelectorAll(".footer-block__heading");

  // Open the first accordion by default
  if (headers.length > 0) {
    const firstHeader = headers[0];
    const firstContent = firstHeader.nextElementSibling;

    firstHeader.classList.add("active");
    firstContent.style.maxHeight = firstContent.scrollHeight + "px";
  }

  headers.forEach((header) => {
    header.addEventListener("click", function () {
      const content = this.nextElementSibling;
      const icon = this.querySelector(".accordion-icon");

      // Close all other accordions
      document.querySelectorAll(".footer-block__details-content").forEach((otherContent) => {
        if (otherContent !== content) {
          otherContent.style.maxHeight = null;
          otherContent.previousElementSibling.querySelector(".accordion-icon").textContent = "+";
          otherContent.previousElementSibling.classList.remove("active");
        }
      });

      // Toggle the clicked accordion
      if (content.style.maxHeight) {
        content.style.maxHeight = null;
        icon.textContent = "+";
        this.classList.remove("active");
      } else {
        content.style.maxHeight = content.scrollHeight + "px";
        icon.textContent = "-";
        this.classList.add("active");
      }
    });
  });
});



